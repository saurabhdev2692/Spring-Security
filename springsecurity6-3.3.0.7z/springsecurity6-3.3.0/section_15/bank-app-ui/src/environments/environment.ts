export const environment = {
  production: true,
  rooturl : 'http://localhost:8080'
};
