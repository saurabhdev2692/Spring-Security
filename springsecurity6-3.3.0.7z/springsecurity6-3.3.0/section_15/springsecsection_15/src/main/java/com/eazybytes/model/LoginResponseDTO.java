package com.eazybytes.model;

public record LoginResponseDTO(String status, String jwtToken) {
}
