package com.eazybytes.model;

public record LoginRequestDTO(String username, String password) {
}
