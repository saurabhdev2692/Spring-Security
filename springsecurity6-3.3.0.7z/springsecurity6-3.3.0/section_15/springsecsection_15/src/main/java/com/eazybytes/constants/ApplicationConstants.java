package com.eazybytes.constants;

public final class ApplicationConstants {

}
